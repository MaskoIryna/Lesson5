package com.si;

public interface Speed {
        int speedCar = 60;
        int speedBacycal = 15;
        String speedMono = "small";
        String km = "km/h";
    }

