package com.si;

public class Transport {
    private String nameTransport;

    public void dry() {
            System.out.println("All transport can dry");
    }

            public String getNameTransport(){
            return nameTransport;
            }
            public void setNameTransport(String nameTransport){
                this.nameTransport = nameTransport;
            }
}

